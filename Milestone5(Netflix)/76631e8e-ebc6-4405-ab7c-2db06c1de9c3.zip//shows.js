const SHOWS = [
  {
    title: "Ginny & Georgia",
    genre: "Drama",
    img: "img/drama/g&g.jpeg",
  },
  {
    title: "The Queen's Gambit",
    genre: "Drama",
    img: "img/drama/tqg.jpeg",
  },
  {
    title: "Outlander",
    genre: "Drama",
    img: "img/drama/outlander.webp",
  },
  {
    title: "Grey's Anatomy",
    genre: "Drama",
    img: "img/drama/ga.webp",
  },
  {
    title: "Ozark",
    genre: "Drama",
    img: "img/drama/ozark.jpeg",
  },
  {
    title: "Avatar: The Last Airbender",
    genre: "Fantasy",
    img: "img/fantasy/atla.webp",
  },
  {
    title: "Supernatural",
    genre: "Fantasy",
    img: "img/fantasy/supernatural.webp",
  },
  {
    title: "The Sandman",
    genre: "Fantasy",
    img: "img/fantasy/sandman.jpeg",
  },
  {
    title: "Wednesday",
    genre: "Fantasy",
    img: "img/fantasy/wednesday.jpeg",
  },
  {
    title: "The Witcher",
    genre: "Fantasy",
    img: "img/fantasy/witcher.jpeg",
  },
  {
    title: "Arrested Development",
    genre: "Comedy",
    img: "img/comedy/ad.jpeg",
  },
  {
    title: "Dead to Me",
    genre: "Comedy",
    img: "img/comedy/dtm.jpeg",
  },
  {
    title: "Seinfeld",
    genre: "Comedy",
    img: "img/comedy/seinfeld.webp",
  },
  {
    title: "Emily in Paris",
    genre: "Comedy",
    img: "img/comedy/eip.jpeg",
  },
  {
    title: "The Good Place",
    genre: "Comedy",
    img: "img/comedy/tgp.webp",
  },
];
